<?
$coordx=$_GET['coordx'];
$coordy=$_GET['coordy'];
?>
<form name="myform">
<input type="text" name="coordx" id="coordx" value="<?=$coordx?>" size="5" />
<input type="text" name="coordy" id="coordy" value="<?=$coordy?>" size="5" />
</form>
